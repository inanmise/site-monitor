package com.sitemonitor.repository;

import com.sitemonitor.model.IncidentRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface IncidentRecordRepository extends JpaRepository<IncidentRecord, Long> {

    /**
     * Filtreli + sayfalı arama. Tüm filtreler opsiyonel (:p IS NULL OR ...).
     * q: serviste önceden lower-case + %..% sarılmış anahtar kelime (title/service/rca/description'da arar).
     * Tarihler ISO-String → sıralanabilir, >= / <= güvenli.
     */
    @Query("""
            SELECT i FROM IncidentRecord i
             WHERE (:q IS NULL OR LOWER(i.title) LIKE :q OR LOWER(i.service) LIKE :q
                                OR LOWER(i.rcaSummary) LIKE :q OR LOWER(i.description) LIKE :q)
               AND (:severity IS NULL OR i.severity = :severity)
               AND (:category IS NULL OR i.category = :category)
               AND (:status   IS NULL OR i.status   = :status)
               AND (:service  IS NULL OR LOWER(i.service) LIKE :service)
               AND (:channel  IS NULL OR LOWER(i.channel) LIKE :channel)
               AND (:since    IS NULL OR i.occurredAt >= :since)
               AND (:until    IS NULL OR i.occurredAt <= :until)
               AND (:teamId   IS NULL OR i.teamId = :teamId)
               AND (:slaBreached IS NULL OR i.slaBreached = :slaBreached)
               AND (:open IS NULL OR (:open = TRUE AND i.status <> 'RESOLVED')
                                  OR (:open = FALSE AND i.status = 'RESOLVED'))
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    Page<IncidentRecord> findFiltered(@Param("q") String q,
                                      @Param("severity") String severity,
                                      @Param("category") String category,
                                      @Param("status") String status,
                                      @Param("service") String service,
                                      @Param("channel") String channel,
                                      @Param("since") String since,
                                      @Param("until") String until,
                                      @Param("teamId") Long teamId,
                                      @Param("slaBreached") Boolean slaBreached,
                                      @Param("open") Boolean open,
                                      @Param("scoped") boolean scoped,
                                      @Param("scope") List<Long> scope,
                                      Pageable pageable);

    /** Aralıktaki olayların occurredAt (UTC ISO) değerleri — günlük trend YEREL gün (Europe/Istanbul)
     *  gruplaması serviste yapılır; UTC SUBSTRING gece-yarısı kayıtlarını bir önceki güne kaydırırdı. */
    @Query("""
            SELECT i.occurredAt FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    List<String> occurredAtInRange(@Param("since") String since, @Param("until") String until,
                                   @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    /** Aralıktaki olayların (occurredAt, severity) çiftleri — günlük trendde ÖNEM kırılımı için; yerel-gün
     *  gruplaması serviste yapılır (occurredAtInRange ile aynı; yalnız severity de seçilir). */
    @Query("""
            SELECT i.occurredAt, i.severity FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    List<Object[]> occurredAtSeverityInRange(@Param("since") String since, @Param("until") String until,
                                             @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    @Query("""
            SELECT i.severity, COUNT(i) FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
             GROUP BY i.severity
            """)
    List<Object[]> countBySeverity(@Param("since") String since, @Param("until") String until,
                                   @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    @Query("""
            SELECT i.status, COUNT(i) FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
             GROUP BY i.status
            """)
    List<Object[]> countByStatus(@Param("since") String since, @Param("until") String until,
                                 @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    @Query("""
            SELECT i.category, COUNT(i) FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
             GROUP BY i.category
            """)
    List<Object[]> countByCategory(@Param("since") String since, @Param("until") String until,
                                   @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    /** Kanal kırılımı (NULL kanallar hariç) — kanal bazlı segmentasyon trendi. */
    @Query("""
            SELECT i.channel, COUNT(i) FROM IncidentRecord i
             WHERE i.channel IS NOT NULL
               AND (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
             GROUP BY i.channel
            """)
    List<Object[]> countByChannel(@Param("since") String since, @Param("until") String until,
                                  @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    @Query("""
            SELECT COUNT(i) FROM IncidentRecord i
             WHERE (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    long countRange(@Param("since") String since, @Param("until") String until,
                    @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    /** Olaylarda fiilen kullanılan farklı kanal/domain değerleri — dropdown union'ı için. Kapsam
     *  olayı OLUŞTURAN takım (createdByTeamId): teamId null → tüm olaylar (admin); dolu → yalnız o
     *  takımın oluşturduğu olaylar → bir takımın eklediği değer başka takıma sızmaz. */
    @Query("SELECT DISTINCT i.channel FROM IncidentRecord i WHERE i.channel IS NOT NULL AND i.channel <> '' AND (:teamId IS NULL OR i.createdByTeamId = :teamId)")
    List<String> distinctChannels(@Param("teamId") Long teamId);

    @Query("SELECT DISTINCT i.service FROM IncidentRecord i WHERE i.service IS NOT NULL AND i.service <> '' AND (:teamId IS NULL OR i.createdByTeamId = :teamId)")
    List<String> distinctServices(@Param("teamId") Long teamId);

    @Query("SELECT DISTINCT i.errorCode FROM IncidentRecord i WHERE i.errorCode IS NOT NULL AND i.errorCode <> '' AND (:teamId IS NULL OR i.createdByTeamId = :teamId)")
    List<String> distinctErrorCodes(@Param("teamId") Long teamId);

    @Query("SELECT DISTINCT i.functionCode FROM IncidentRecord i WHERE i.functionCode IS NOT NULL AND i.functionCode <> '' AND (:teamId IS NULL OR i.createdByTeamId = :teamId)")
    List<String> distinctFunctionCodes(@Param("teamId") Long teamId);

    @Query("SELECT DISTINCT i.channelCode FROM IncidentRecord i WHERE i.channelCode IS NOT NULL AND i.channelCode <> '' AND (:teamId IS NULL OR i.createdByTeamId = :teamId)")
    List<String> distinctChannelCodes(@Param("teamId") Long teamId);

    @Query("""
            SELECT COUNT(i) FROM IncidentRecord i
             WHERE i.slaBreached = true
               AND (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    long countSlaBreached(@Param("since") String since, @Param("until") String until,
                          @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    /** SLA içinde çözülen: status=RESOLVED ve SLA ihlali yok. */
    @Query("""
            SELECT COUNT(i) FROM IncidentRecord i
             WHERE i.status = 'RESOLVED' AND i.slaBreached = false
               AND (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    long countResolvedWithinSla(@Param("since") String since, @Param("until") String until,
                                @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);

    @Query("""
            SELECT COUNT(i) FROM IncidentRecord i
             WHERE i.status <> 'RESOLVED'
               AND (:since IS NULL OR i.occurredAt >= :since)
               AND (:until IS NULL OR i.occurredAt <= :until)
               AND (:scoped = FALSE OR i.teamId IN :scope OR i.createdByTeamId IN :scope)
            """)
    long countOpen(@Param("since") String since, @Param("until") String until,
                   @Param("scoped") boolean scoped, @Param("scope") List<Long> scope);
}
