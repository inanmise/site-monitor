package com.sitemonitor.service.report;

import com.sitemonitor.model.AlertEvent;
import com.sitemonitor.model.MaintenanceWindow;
import com.sitemonitor.model.Team;
import com.sitemonitor.repository.AlertEventRepository;
import com.sitemonitor.repository.MaintenanceWindowRepository;
import com.sitemonitor.repository.NotificationLogRepository;
import com.sitemonitor.service.EmailNotificationService.AvailabilityRow;
import com.sitemonitor.service.MaintenanceService;
import com.sitemonitor.service.MonitoringWeeklyStatsService;
import com.sitemonitor.service.WeeklyAvailabilityReportService.Window;
import com.sitemonitor.service.report.WeeklyOutageReportService.OutageRow;
import com.sitemonitor.service.report.WeeklyOutageReportService.TypeGroup;
import com.sitemonitor.service.report.WeeklyOutageReportService.WeeklyOutageData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.data.domain.PageImpl;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

/**
 * Haftalık kesinti raporunun VERİ katmanı — türetilen alanların hepsi burada sınanır.
 *
 * <p>Pencere: 15–21 Haziran 2026 (Pzt–Paz), Europe/Istanbul. Saat dilimi bilinçli olarak sabit
 * seçildi: gün/saat kovaları IST'e göre hesaplanıyor ve UTC damgalarla test edilirse CI (UTC)
 * ile yerel makine farklı sonuç verirdi.
 */
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class WeeklyOutageReportServiceTest {

    @Mock AlertEventRepository alertEventRepo;
    @Mock NotificationLogRepository notificationLogRepo;
    @Mock MaintenanceWindowRepository maintenanceRepo;
    @Mock MaintenanceService maintenanceService;
    @Mock MonitoringWeeklyStatsService weeklyStatsService;

    private WeeklyOutageReportService service;

    /** 15 Haziran 2026 Pzt 00:00 IST = 14 Haziran 21:00 UTC; 21 Haziran 23:59:59 IST = 20:59:59 UTC. */
    private static final Window W = new Window(
            "2026-06-14T21:00:00", "2026-06-21T20:59:59",
            Instant.parse("2026-06-21T20:59:59Z"), 2026, 25, "15–21 Haziran 2026");

    private static final Team TEAM = team();

    private static Team team() {
        Team t = new Team();
        t.setId(5L);
        t.setName("Dijital SY");
        return t;
    }

    @BeforeEach
    void setUp() {
        service = new WeeklyOutageReportService(alertEventRepo, notificationLogRepo,
                maintenanceRepo, maintenanceService, weeklyStatsService);
        when(maintenanceRepo.findAll()).thenReturn(List.of());
        when(notificationLogRepo.countByAlertIds(any())).thenReturn(List.of());
        when(alertEventRepo.countFilteredByType(any(), any(), any(), any(), any(), any(), anyBoolean(), any()))
                .thenReturn(List.of());
        when(weeklyStatsService.compute(anyLong(), anyInt(), anyInt())).thenReturn(null);
        stubAlarms(List.of(), List.of(), List.of());
    }

    /** Üç kapsam sorgusunu ayrı ayrı besler: hafta içi açılanlar / devreden açıklar / devreden çözülenler. */
    private void stubAlarms(List<AlertEvent> opened, List<AlertEvent> carriedOpen, List<AlertEvent> carriedResolved) {
        when(alertEventRepo.findFiltered(isNull(), eq(W.fromUtc()), eq(W.toUtc()),
                isNull(), isNull(), isNull(), isNull(), eq(true), any(), any()))
                .thenReturn(new PageImpl<>(opened));
        when(alertEventRepo.findFiltered(eq(false), isNull(), eq(W.fromUtc()),
                isNull(), isNull(), isNull(), isNull(), eq(true), any(), any()))
                .thenReturn(new PageImpl<>(carriedOpen));
        when(alertEventRepo.findFiltered(eq(true), isNull(), eq(W.fromUtc()),
                eq(W.fromUtc()), isNull(), isNull(), isNull(), eq(true), any(), any()))
                .thenReturn(new PageImpl<>(carriedResolved));
    }

    private static AlertEvent alarm(long id, String domain, String type, String createdAt) {
        AlertEvent e = new AlertEvent();
        e.setId(id);
        e.setDomain(domain);
        e.setAlertType(type);
        e.setAlertLevel("CRITICAL");
        e.setCreatedAt(createdAt);
        e.setResolved(false);
        return e;
    }

    /** Seviyesi belirtilmiş alarm — seviye dağılımı testleri için. */
    private static AlertEvent level(long id, String domain, String lvl) {
        AlertEvent e = alarm(id, domain, "HTTP_DOWN", "2026-06-16T09:00:00");
        e.setAlertLevel(lvl);
        return e;
    }

    private static AlertEvent resolved(long id, String domain, String type, String from, String to) {
        AlertEvent e = alarm(id, domain, type, from);
        e.setResolved(true);
        e.setResolvedAt(to);
        return e;
    }

    private WeeklyOutageData collect() {
        return service.collect(TEAM, W, List.of());
    }

    // ── Süre hesabı ──────────────────────────────────────────────────────────

    @Test
    @DisplayName("Çözülmüş alarmın süresi açılış→çözülüş; açık alarmın süresi PENCERE SONUNA kadar")
    void duration_closedUsesResolvedAt_openUsesWindowEnd() {
        stubAlarms(List.of(
                resolved(1, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00", "2026-06-16T11:30:00"),
                alarm(2, "b.com", "HTTP_DOWN", "2026-06-21T18:59:59")), List.of(), List.of());

        Map<String, OutageRow> byTarget = index(collect());

        assertThat(byTarget.get("a.com").durationMin()).isEqualTo(150);   // 2 sa 30 dk
        // Açık alarm pencere sonuna (21 Haz 20:59:59Z) kadar = 2 saat. "Şu ana kadar" deseydik
        // geçmiş bir haftanın raporu her üretimde farklı süre gösterirdi.
        assertThat(byTarget.get("b.com").durationMin()).isEqualTo(120);
        assertThat(byTarget.get("b.com").stillOpen()).isTrue();
    }

    @Test
    @DisplayName("humanDuration: ham dakika yerine okunur süre")
    void humanDuration_readable() {
        assertThat(WeeklyOutageReportService.humanDuration(0)).isEqualTo("< 1 dk");
        assertThat(WeeklyOutageReportService.humanDuration(45)).isEqualTo("45dk");
        assertThat(WeeklyOutageReportService.humanDuration(150)).isEqualTo("2sa 30dk");
        assertThat(WeeklyOutageReportService.humanDuration(1440)).isEqualTo("1g");
        assertThat(WeeklyOutageReportService.humanDuration(3075)).isEqualTo("2g 3sa 15dk");
    }

    @Test
    @DisplayName("Bozuk/eksik zaman damgası süreyi negatif ya da NaN yapmaz")
    void duration_brokenStampsAreSafe() {
        AlertEvent broken = alarm(1, "a.com", "HTTP_DOWN", "bozuk-damga");
        AlertEvent backwards = resolved(2, "b.com", "HTTP_DOWN",
                "2026-06-16T12:00:00", "2026-06-16T09:00:00");   // çözülüş açılıştan ÖNCE
        stubAlarms(List.of(broken, backwards), List.of(), List.of());

        Map<String, OutageRow> byTarget = index(collect());
        assertThat(byTarget.get("a.com").durationMin()).isZero();
        assertThat(byTarget.get("b.com").durationMin()).isZero();
    }

    // ── Devreden kesintiler ──────────────────────────────────────────────────

    @Test
    @DisplayName("ÖNCEKİ HAFTADAN DEVREDEN alarmlar da rapora girer ve «devreden» işaretlenir")
    void carriedOverAlarmsAreIncludedAndFlagged() {
        // Hafta başlamadan açılmış, hâlâ açık — haftanın en uzun kesintisi bu olabilir.
        AlertEvent carried = alarm(9, "eski.com", "PORT_DOWN", "2026-06-10T08:00:00");
        stubAlarms(List.of(alarm(1, "yeni.com", "HTTP_DOWN", "2026-06-16T09:00:00")),
                List.of(carried), List.of());

        WeeklyOutageData d = collect();

        assertThat(d.totalAlarms()).isEqualTo(2);
        assertThat(d.carriedOverCount()).isEqualTo(1);
        Map<String, OutageRow> byTarget = index(d);
        assertThat(byTarget.get("eski.com").carriedOver()).isTrue();
        assertThat(byTarget.get("yeni.com").carriedOver()).isFalse();
    }

    @Test
    @DisplayName("Üç kapsam sorgusunun kesişimi ID ile TEKİLLEŞTİRİLİR — alarm iki kez sayılmaz")
    void overlappingQueriesAreDeduplicatedById() {
        AlertEvent same = alarm(7, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00");
        stubAlarms(List.of(same), List.of(same), List.of(same));

        assertThat(collect().totalAlarms()).isEqualTo(1);
    }

    // ── Bildirim boşluğu ─────────────────────────────────────────────────────

    @Test
    @DisplayName("Hiç BAŞARILI bildirim yoksa alarm «bildirim ulaşmadı» listesine girer")
    void notifyGapListsAlarmsThatReachedNobody() {
        stubAlarms(List.of(
                alarm(1, "ulasti.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                alarm(2, "ulasmadi.com", "HTTP_DOWN", "2026-06-16T10:00:00"),
                alarm(3, "hickayit.com", "HTTP_DOWN", "2026-06-16T11:00:00")), List.of(), List.of());
        when(notificationLogRepo.countByAlertIds(any())).thenReturn(List.<Object[]>of(
                new Object[]{ 1L, 2L, 0L },      // 2 gönderildi
                new Object[]{ 2L, 0L, 3L }));    // 0 gönderildi, 3 başarısız; 3 numaralı hiç kayıtsız

        WeeklyOutageData d = collect();

        assertThat(d.notifyGaps()).extracting(OutageRow::target)
                .containsExactlyInAnyOrder("ulasmadi.com", "hickayit.com");
        Map<String, OutageRow> byTarget = index(d);
        assertThat(byTarget.get("ulasti.com").notifySent()).isEqualTo(2);
        assertThat(byTarget.get("ulasmadi.com").notifyFailed()).isEqualTo(3);
    }

    // ── Bakım işareti ────────────────────────────────────────────────────────

    @Test
    @DisplayName("Bakım penceresine denk gelen alarm işaretlenir; hedefi kapsamayan pencere işaretlemez")
    void maintenanceOverlapMarksOnlyCoveredTargets() {
        MaintenanceWindow win = new MaintenanceWindow();
        win.setId(1L);
        when(maintenanceRepo.findAll()).thenReturn(List.of(win));
        when(maintenanceService.isActiveAt(eq(win), any())).thenReturn(true);
        when(maintenanceService.targetsOf(win)).thenReturn(List.of("bakimda.com"));
        stubAlarms(List.of(
                alarm(1, "bakimda.com", "HTTP_DOWN", "2026-06-16T02:00:00"),
                alarm(2, "baska.com", "HTTP_DOWN", "2026-06-16T02:00:00")), List.of(), List.of());

        Map<String, OutageRow> byTarget = index(collect());

        assertThat(byTarget.get("bakimda.com").maintenanceOverlap()).isTrue();
        assertThat(byTarget.get("baska.com").maintenanceOverlap()).isFalse();
    }

    @Test
    @DisplayName("allMonitors penceresi HER hedefi kapsar")
    void maintenanceAllMonitorsCoversEveryTarget() {
        MaintenanceWindow win = new MaintenanceWindow();
        win.setAllMonitors(true);
        when(maintenanceRepo.findAll()).thenReturn(List.of(win));
        when(maintenanceService.isActiveAt(eq(win), any())).thenReturn(true);
        stubAlarms(List.of(alarm(1, "her.com", "HTTP_DOWN", "2026-06-16T02:00:00")), List.of(), List.of());

        assertThat(index(collect()).get("her.com").maintenanceOverlap()).isTrue();
    }

    @Test
    @DisplayName("Bakım pencereleri okunamazsa rapor ÇÖKMEZ, yalnız bakım işareti çizilmez")
    void maintenanceReadFailureDoesNotBreakReport() {
        when(maintenanceRepo.findAll()).thenThrow(new RuntimeException("db down"));
        stubAlarms(List.of(alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00")), List.of(), List.of());

        WeeklyOutageData d = collect();
        assertThat(d.totalAlarms()).isEqualTo(1);
        assertThat(d.maintenanceOverlapCount()).isZero();
    }

    // ── Gruplama ─────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Alarmlar izleme türüne göre gruplanır; BİLİNMEYEN tip «Diğer»e düşer, kaybolmaz")
    void groupsByMonitorType_unknownFallsToOther() {
        stubAlarms(List.of(
                alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                alarm(2, "b.com", "PORT_DOWN", "2026-06-16T10:00:00"),
                alarm(3, "c.com", "PAGE_INTEGRITY", "2026-06-16T11:00:00"),
                alarm(4, "d.com", "BOYLE_BIR_TIP_YOK", "2026-06-16T12:00:00")), List.of(), List.of());

        List<TypeGroup> groups = collect().groups();

        assertThat(groups).extracting(TypeGroup::label)
                .containsExactly("HTTP/Website", "Port", "Sayfa Bütünlüğü", "Diğer");
        // Hiçbir alarm düşmedi diye kaybolmasın: toplam satır sayısı korunur.
        assertThat(groups.stream().mapToInt(g -> g.rows().size()).sum()).isEqualTo(4);
    }

    @Test
    @DisplayName("Sayfa bütünlüğü alarmları artık kendi türüne düşüyor (eskiden hiçbir kovaya girmiyordu)")
    void pageIntegrityAlarmsAreClassified() {
        stubAlarms(List.of(alarm(1, "a.com", "PAGE_DOWN", "2026-06-16T09:00:00")), List.of(), List.of());
        assertThat(index(collect()).get("a.com").monitorType()).isEqualTo("page");
    }

    // ── Tekrar edenler ───────────────────────────────────────────────────────

    @Test
    @DisplayName("Aynı hedef+tip için ≥2 alarm «tekrar eden» sayılır; tek seferlikler listelenmez")
    void repeatsOnlyCountTwoOrMore() {
        stubAlarms(List.of(
                alarm(1, "kronik.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                alarm(2, "kronik.com", "HTTP_DOWN", "2026-06-17T09:00:00"),
                alarm(3, "kronik.com", "HTTP_DOWN", "2026-06-18T09:00:00"),
                alarm(4, "tekil.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                // aynı hedef ama FARKLI tip → ayrı sayılır, tekrar değil
                alarm(5, "kronik.com", "PORT_DOWN", "2026-06-16T09:00:00")), List.of(), List.of());

        assertThat(collect().repeats())
                .extracting(r -> r.target() + "/" + r.alertType() + "=" + r.count())
                .containsExactly("kronik.com/HTTP_DOWN=3");
    }

    @Test
    @DisplayName("Hedef adında BOŞLUK olsa da tekrar sayımı doğru — ayırıcıyla paketleme tuzağı")
    void repeatsHandleTargetsContainingSpaces() {
        // Canlı veride böyle hedefler VAR: "http://localhost:8080/health- Orjinal".
        // Anahtar "hedef + boşluk + tip" diye paketlenip boşlukla bölünseydi hedef ikiye kesilir,
        // alarm tipi yanlış okunur ve ("a b","C") ile ("a","b C") aynı anahtara düşerdi.
        String spaced = "http://localhost:8080/health- Orjinal";
        stubAlarms(List.of(
                alarm(1, spaced, "KEYWORD_SSL", "2026-06-16T09:00:00"),
                alarm(2, spaced, "KEYWORD_SSL", "2026-06-17T09:00:00"),
                // Naif bölmede bu ikisi çakışırdı: ("a b","C") ve ("a","b C")
                alarm(3, "a b", "C", "2026-06-16T09:00:00"),
                alarm(4, "a", "b C", "2026-06-16T10:00:00")), List.of(), List.of());

        var repeats = collect().repeats();

        // Hedef BÜTÜN olarak korunur ve tip doğru kalır.
        assertThat(repeats).extracting(WeeklyOutageReportService.RepeatItem::target)
                .containsExactly(spaced);
        assertThat(repeats).extracting(WeeklyOutageReportService.RepeatItem::alertType)
                .containsExactly("KEYWORD_SSL");
        assertThat(repeats.get(0).count()).isEqualTo(2);
        // ("a b","C") ile ("a","b C") AYRI kalır → hiçbiri 2'ye ulaşmaz, listede yok.
        assertThat(repeats).hasSize(1);
    }

    // ── Gün / saat dağılımı ──────────────────────────────────────────────────

    @Test
    @DisplayName("Gün ve saat kovaları Europe/Istanbul'a göre — UTC'ye göre olsaydı gün kayardı")
    void bucketsUseIstanbulTime() {
        // 16 Haziran 2026 Salı, 22:30 UTC = 17 Haziran Çarşamba 01:30 IST.
        stubAlarms(List.of(alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T22:30:00")), List.of(), List.of());

        WeeklyOutageData d = collect();

        assertThat(d.byDay()).filteredOn(b -> b.count() > 0)
                .extracting(WeeklyOutageReportService.Bucket::label)
                .containsExactly("Çarşamba");
        assertThat(d.byHour()).extracting(WeeklyOutageReportService.Bucket::label).containsExactly("01:00");
    }

    @Test
    @DisplayName("Alarm düşmeyen saatler listelenmez — sıfır satırlar deseni boğardı")
    void hourBucketsOmitEmptyHours() {
        stubAlarms(List.of(
                alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T06:00:00"),
                alarm(2, "b.com", "HTTP_DOWN", "2026-06-16T06:30:00")), List.of(), List.of());

        assertThat(collect().byHour()).hasSize(1);
        assertThat(collect().byDay()).hasSize(7);   // günler tam hafta gösterilir
    }

    // ── Özet ─────────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Özet: toplam/açık/etkilenen hedef/toplam süre; aynı hedefin iki alarmı hedefi bir kez sayar")
    void summaryCounts() {
        stubAlarms(List.of(
                resolved(1, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00", "2026-06-16T10:00:00"),
                resolved(2, "a.com", "PORT_DOWN", "2026-06-17T09:00:00", "2026-06-17T09:30:00"),
                alarm(3, "b.com", "HTTP_DOWN", "2026-06-21T19:59:59")), List.of(), List.of());

        WeeklyOutageData d = collect();

        assertThat(d.totalAlarms()).isEqualTo(3);
        assertThat(d.stillOpenCount()).isEqualTo(1);
        assertThat(d.affectedTargets()).isEqualTo(2);          // a.com iki alarm ama TEK hedef
        assertThat(d.totalDowntimeMin()).isEqualTo(60 + 30 + 60);
        assertThat(d.quietWeek()).isFalse();
    }

    @Test
    @DisplayName("TOPLAM kesinti süresi haftaya KIRPILIR — devreden alarm haftalık raporu şişirmez")
    void totalDowntimeIsClippedToTheWeek() {
        // 5 Haziran'da açılmış, hâlâ açık: gerçek süresi ~16 gün. Ham süre toplansaydı bir
        // haftalık rapor "16 gün kesinti" derdi. Gerçek veride bu 254 GÜN olarak görünmüştü.
        stubAlarms(List.of(), List.of(alarm(9, "eski.com", "PORT_DOWN", "2026-06-05T08:00:00")), List.of());

        WeeklyOutageData d = collect();
        OutageRow r = index(d).get("eski.com");

        // Detay satırı GERÇEK süreyi gösterir (alarmın kendisi hakkındaki doğru bilgi)...
        assertThat(r.durationMin()).isGreaterThan(20_000);
        // ...ama özet yalnız haftaya düşen payı sayar: tam hafta = 7×1440 - 1 dk (23:59:59 sınırı).
        assertThat(r.weekDurationMin()).isEqualTo(10_080);
        assertThat(d.totalDowntimeMin()).isEqualTo(10_080);
    }

    @Test
    @DisplayName("Haftadan SONRA çözülen alarmın payı da hafta sonunda kesilir")
    void weekShareIsClippedAtWindowEnd() {
        // Hafta içinde açıldı, hafta bittikten çok sonra çözüldü.
        stubAlarms(List.of(resolved(1, "a.com", "HTTP_DOWN",
                "2026-06-21T19:59:59", "2026-06-30T12:00:00")), List.of(), List.of());

        OutageRow r = index(collect()).get("a.com");
        assertThat(r.weekDurationMin()).isEqualTo(60);            // yalnız 20:59:59'a kadar
        assertThat(r.durationMin()).isGreaterThan(10_000);        // gerçek süre çok daha uzun
    }

    @Test
    @DisplayName("Hiç alarm yoksa quietWeek — PDF yine üretilir (kesintisiz haftada da ek gider)")
    void quietWeek() {
        WeeklyOutageData d = collect();
        assertThat(d.quietWeek()).isTrue();
        assertThat(d.totalAlarms()).isZero();
        assertThat(d.groups()).isEmpty();
    }

    @Test
    @DisplayName("Ortalama erişilebilirlik: bir domain bile %100 değilse 100,00 GÖSTERİLMEZ")
    void avgAvailabilityNeverFakes100() {
        List<AvailabilityRow> rows = List.of(
                new AvailabilityRow("a.com", 100.0, 0, 0, 0, 100L, 120L, 40),
                new AvailabilityRow("b.com", 99.995, 1, 1, 1, 100L, 120L, 40));

        WeeklyOutageData d = service.collect(TEAM, W, rows);

        // Yuvarlama 100,00'e çekerdi; haftalık e-postanın summarize'ı ile AYNI kural uygulanır,
        // yoksa gövde ile ek çelişirdi.
        assertThat(d.avgAvailabilityPct()).isEqualTo(99.99);
    }

    @Test
    @DisplayName("Tür istatistikleri alınamazsa kesinti detayı yine üretilir")
    void typeStatsFailureDoesNotBreakReport() {
        when(weeklyStatsService.compute(anyLong(), anyInt(), anyInt()))
                .thenThrow(new RuntimeException("cache patladı"));
        stubAlarms(List.of(alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T09:00:00")), List.of(), List.of());

        WeeklyOutageData d = collect();
        assertThat(d.typeStats()).isEmpty();
        assertThat(d.totalAlarms()).isEqualTo(1);
    }

    // ── Hafta karşılaştırması ve dağılım paydası ─────────────────────────────

    @Test
    @DisplayName("Delta yalnız AÇILAN alarmları karşılaştırır — devreden alarm karşılaştırmayı ŞİŞİRMEZ")
    void deltaComparesOnlyAlarmsOpenedInTheWeek() {
        // Geçen hafta 3 alarm açılmış.
        when(alertEventRepo.countFilteredByType(any(), any(), any(), any(), any(), any(), anyBoolean(), any()))
                .thenReturn(List.<Object[]>of(new Object[]{ "HTTP_DOWN", 3L }));
        // Bu hafta 2 alarm AÇILDI; ayrıca 3 alarm önceki haftalardan devretti.
        stubAlarms(List.of(
                        alarm(1, "yeni1.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                        alarm(2, "yeni2.com", "PORT_DOWN", "2026-06-17T09:00:00")),
                List.of(
                        alarm(11, "eski1.com", "HTTP_DOWN", "2026-06-01T00:00:00"),
                        alarm(12, "eski2.com", "PORT_DOWN", "2026-06-01T00:00:00"),
                        alarm(13, "eski3.com", "DNS_FAILURE", "2026-06-01T00:00:00")),
                List.of());

        WeeklyOutageData d = collect();

        // Özet "hafta içinde açık olan" sayısını göstermeye devam eder...
        assertThat(d.totalAlarms()).isEqualTo(5);
        assertThat(d.carriedOverCount()).isEqualTo(3);
        // ...ama KARŞILAŞTIRMA iki tarafta da yalnız o hafta AÇILANLARI sayar.
        assertThat(d.alarmsOpenedThisWeek()).isEqualTo(2);
        assertThat(d.alarmsPrevWeek()).isEqualTo(3);
        assertThat(d.alarmsDelta()).isEqualTo(-1);   // 2 - 3, devredenler karışmaz
    }

    @Test
    @DisplayName("Devreden alarm eklemek deltayı DEĞİŞTİRMEZ — bu hafta hiçbir şey açılmadı")
    void carriedOverAlarmsDoNotMoveTheDelta() {
        when(alertEventRepo.countFilteredByType(any(), any(), any(), any(), any(), any(), anyBoolean(), any()))
                .thenReturn(List.<Object[]>of(new Object[]{ "HTTP_DOWN", 2L }));
        // Hafta içinde HİÇ alarm açılmadı; yalnız eski alarmlar sürüyor.
        stubAlarms(List.of(), List.of(
                alarm(11, "eski1.com", "HTTP_DOWN", "2026-06-01T00:00:00"),
                alarm(12, "eski2.com", "PORT_DOWN", "2026-06-01T00:00:00"),
                alarm(13, "eski3.com", "DNS_FAILURE", "2026-06-01T00:00:00"),
                alarm(14, "eski4.com", "PING_DOWN", "2026-06-01T00:00:00")), List.of());

        WeeklyOutageData d = collect();

        assertThat(d.alarmsOpenedThisWeek()).isZero();
        assertThat(d.alarmsDelta()).isEqualTo(-2);   // 0 açıldı, geçen hafta 2 → azalış
    }

    @Test
    @DisplayName("Gün/saat/ısı dağılımı DEVREDEN alarmları saymaz — başlangıçları bu haftanın DIŞINDA")
    void distributionsCountOnlyAlarmsOpenedInTheWindow() {
        // 2026-06-16T09:00Z = Salı 12:00 IST (pencere içi)
        // 2026-06-01T00:00Z = 1 Haziran Pazartesi 03:00 IST — pencereden İKİ HAFTA önce.
        // Devredenler süzülmezse Pazartesi kutusuna düşer ve rapor "bu hafta pazartesi 3 alarm
        // açıldı" der; oysa o gün bu haftaya ait bile değil.
        stubAlarms(List.of(
                        alarm(1, "yeni1.com", "HTTP_DOWN", "2026-06-16T09:00:00"),
                        alarm(2, "yeni2.com", "PORT_DOWN", "2026-06-16T09:30:00")),
                List.of(
                        alarm(11, "eski1.com", "HTTP_DOWN", "2026-06-01T00:00:00"),
                        alarm(12, "eski2.com", "PORT_DOWN", "2026-06-01T00:00:00"),
                        alarm(13, "eski3.com", "DNS_FAILURE", "2026-06-01T00:00:00")),
                List.of());

        WeeklyOutageData d = collect();

        // Paydalar birbirini tutmalı: dağılım = bu hafta açılanlar.
        int dayTotal = d.byDay().stream().mapToInt(WeeklyOutageReportService.Bucket::count).sum();
        int hourTotal = d.byHour().stream().mapToInt(WeeklyOutageReportService.Bucket::count).sum();
        int heatTotal = d.heat().stream().flatMap(r -> r.hours().stream()).mapToInt(Integer::intValue).sum();

        assertThat(dayTotal).isEqualTo(2);
        assertThat(hourTotal).isEqualTo(2);
        assertThat(heatTotal).isEqualTo(2);
        assertThat(dayTotal).isEqualTo(d.alarmsOpenedThisWeek());

        // Pazartesi kutusu BOŞ olmalı — 1 Haziran bu haftanın pazartesisi değil.
        assertThat(d.byDay().get(0).label()).isEqualTo("Pazartesi");
        assertThat(d.byDay().get(0).count()).isZero();
        assertThat(d.heat().get(0).hours()).allMatch(v -> v == 0);
    }

    // ── Grafik verisi ────────────────────────────────────────────────────────

    @Test
    @DisplayName("Zaman çizelgesi HEDEF başına satır verir; aynı hedefin iki alarmı tek satırda birleşir")
    void timelineGroupsSegmentsByTarget() {
        stubAlarms(List.of(
                resolved(1, "a.com", "HTTP_DOWN", "2026-06-15T09:00:00", "2026-06-15T10:00:00"),
                resolved(2, "a.com", "PORT_DOWN", "2026-06-17T09:00:00", "2026-06-17T09:30:00"),
                resolved(3, "b.com", "HTTP_DOWN", "2026-06-16T09:00:00", "2026-06-16T09:15:00")), List.of(), List.of());

        var timeline = collect().timeline();

        assertThat(timeline).hasSize(2);
        // En uzun toplam kesinti ÜSTTE — grafiği okuyan önce en kötüyü görsün.
        assertThat(timeline.get(0).target()).isEqualTo("a.com");
        assertThat(timeline.get(0).segments()).hasSize(2);
        assertThat(timeline.get(0).totalMin()).isEqualTo(90);   // 60 + 30, çakışma yok
        assertThat(timeline.get(1).target()).isEqualTo("b.com");
    }

    @Test
    @DisplayName("Çizelge süresi ÇAKIŞAN alarmları iki kez saymaz — 7 günlük çizelgede 21 gün yazamaz")
    void timelineTotalIsUnionNotSum() {
        // Aynı hedefte üç alarm AYNI ANDA açık (sertifika + HTTP + port birlikte düştü).
        // Ham toplam alınsaydı canlı veride görüldüğü gibi "21g" yazardı.
        stubAlarms(List.of(), List.of(
                alarm(1, "cakisan.com", "EXPIRY", "2026-06-01T00:00:00"),
                alarm(2, "cakisan.com", "HTTP_DOWN", "2026-06-01T00:00:00"),
                alarm(3, "cakisan.com", "PORT_DOWN", "2026-06-01T00:00:00")), List.of());

        var row = collect().timeline().get(0);

        assertThat(row.segments()).hasSize(3);                 // çubuklar korunur
        assertThat(row.totalMin()).isEqualTo(10_080);          // ama süre TEK hafta = 7×1440
    }

    @Test
    @DisplayName("Birleşim hesabı: ayrık, çakışan, bitişik ve iç içe aralıklar")
    void unionMinutesCoversTheEdgeCases() {
        java.util.function.BiFunction<Long, Long, WeeklyOutageReportService.TimelineSegment> seg =
                (s, d) -> new WeeklyOutageReportService.TimelineSegment(s, d, "CRITICAL", false);

        // Ayrık: 0-10 ve 20-30 → 20
        assertThat(WeeklyOutageReportService.unionMinutes(List.of(seg.apply(0L, 10L), seg.apply(20L, 10L))))
                .isEqualTo(20);
        // Çakışan: 0-10 ve 5-15 → 15
        assertThat(WeeklyOutageReportService.unionMinutes(List.of(seg.apply(0L, 10L), seg.apply(5L, 10L))))
                .isEqualTo(15);
        // Bitişik: 0-10 ve 10-20 → 20 (tek kesinti gibi okunur)
        assertThat(WeeklyOutageReportService.unionMinutes(List.of(seg.apply(0L, 10L), seg.apply(10L, 10L))))
                .isEqualTo(20);
        // İç içe: 0-100 ve 20-30 → 100 (kısa olan uzunun içinde kaybolur)
        assertThat(WeeklyOutageReportService.unionMinutes(List.of(seg.apply(0L, 100L), seg.apply(20L, 10L))))
                .isEqualTo(100);
        // Sırasız girdi de doğru sonuç vermeli
        assertThat(WeeklyOutageReportService.unionMinutes(List.of(seg.apply(50L, 10L), seg.apply(0L, 10L))))
                .isEqualTo(20);
        assertThat(WeeklyOutageReportService.unionMinutes(List.of())).isZero();
    }

    @Test
    @DisplayName("Çizelge konumu pencere BAŞINA göre; devreden alarm 0'dan başlar")
    void timelineOffsetsAreRelativeToWindowStart() {
        stubAlarms(List.of(
                // 15 Haziran Pzt 00:00 IST = pencere başı. 09:00 IST → 540 dk sonra.
                resolved(1, "gec.com", "HTTP_DOWN", "2026-06-15T06:00:00", "2026-06-15T07:00:00")),
                List.of(alarm(2, "devreden.com", "PORT_DOWN", "2026-06-01T00:00:00")), List.of());

        var byTarget = collect().timeline().stream()
                .collect(java.util.stream.Collectors.toMap(r -> r.target(), r -> r));

        // 06:00 UTC = 09:00 IST → pencere başından 540 dk.
        assertThat(byTarget.get("gec.com").segments().get(0).startOffsetMin()).isEqualTo(540);
        // Devreden alarm haftadan ÖNCE açıldı → çubuk pencerenin en başından başlar.
        assertThat(byTarget.get("devreden.com").segments().get(0).startOffsetMin()).isZero();
    }

    @Test
    @DisplayName("Isı haritası 7×24 ızgara; sayım doğru hücreye Europe/Istanbul ile düşer")
    void heatmapIsSevenByTwentyFour() {
        // 16 Haziran Salı 22:30 UTC = 17 Haziran ÇARŞAMBA 01:30 IST.
        stubAlarms(List.of(alarm(1, "a.com", "HTTP_DOWN", "2026-06-16T22:30:00")), List.of(), List.of());

        var heat = collect().heat();

        assertThat(heat).hasSize(7);
        assertThat(heat).allSatisfy(r -> assertThat(r.hours()).hasSize(24));
        assertThat(heat.get(2).day()).isEqualTo("Çarşamba");
        assertThat(heat.get(2).hours().get(1)).isEqualTo(1);
        // Başka hiçbir hücreye sızmamalı.
        assertThat(heat.stream().flatMap(r -> r.hours().stream()).mapToInt(Integer::intValue).sum()).isEqualTo(1);
    }

    @Test
    @DisplayName("Seviye dağılımı SABİT sırada — grafik renkleri hafta hafta kaymaz")
    void levelBucketsUseFixedOrder() {
        stubAlarms(List.of(
                level(1, "a.com", "WARNING"), level(2, "b.com", "CRITICAL"),
                level(3, "c.com", "HIGH"), level(4, "d.com", "CRITICAL")), List.of(), List.of());

        var byLevel = collect().byLevel();

        // Veri sırasına bırakılsaydı (WARNING önce geldi) iki haftanın grafiğinde aynı renk
        // farklı seviyeyi gösterirdi.
        assertThat(byLevel).extracting(WeeklyOutageReportService.Bucket::label)
                .containsExactly("CRITICAL", "HIGH", "WARNING");
        assertThat(byLevel.get(0).count()).isEqualTo(2);
        // Sıfır olan seviyeler çizilmez — boş dilim gürültüdür.
        assertThat(byLevel).noneMatch(b -> b.count() == 0);
    }

    @Test
    @DisplayName("Bilinmeyen seviye dağılımdan DÜŞMEZ, 'OTHER' kovasına girer")
    void unknownLevelFallsToOtherBucket() {
        stubAlarms(List.of(level(1, "a.com", "BOYLE_BIR_SEVIYE_YOK")), List.of(), List.of());

        assertThat(collect().byLevel())
                .extracting(WeeklyOutageReportService.Bucket::label)
                .containsExactly("OTHER");
    }

    // ── En uzunlar / sertifika / bakım hazırlığı ─────────────────────────────

    @Test
    @DisplayName("«En uzunlar» HAFTAYA DÜŞEN süreye göre sıralanır — devreden alarm listeyi kapatmaz")
    void longestRanksByWeekShareNotRawDuration() {
        // İKİ SIRALAMANIN ÇELİŞTİĞİ senaryo — testin bir şey kanıtlaması için şart:
        //   buhafta.com : 10 saat, tamamı bu hafta   → hafta payı 600 dk, ham 600 dk
        //   eski.com    : iki hafta önce açıldı ama pazartesi sabahı ÇÖZÜLDÜ
        //                 → hafta payı yalnız 4 saat (240 dk), ham süre ~14 gün (20 000+ dk)
        // Ham süreye göre sıralanırsa eski.com üstte çıkar ve bu haftanın asıl kesintisi altta
        // kalır; haftaya düşen paya göre sıralanırsa doğru olan buhafta.com üste gelir.
        stubAlarms(List.of(
                        resolved(1, "buhafta.com", "HTTP_DOWN",
                                "2026-06-17T06:00:00", "2026-06-17T16:00:00")),
                List.of(),
                List.of(resolved(11, "eski.com", "PORT_DOWN",
                        "2026-06-01T00:00:00", "2026-06-15T01:00:00")));

        var longest = collect().longest();

        assertThat(longest).hasSize(2);
        assertThat(longest.get(0).target()).isEqualTo("buhafta.com");   // ham süreye göre 2. olurdu
        assertThat(longest.get(0).weekDurationMin()).isEqualTo(600);
        assertThat(longest.get(1).target()).isEqualTo("eski.com");
        assertThat(longest.get(1).weekDurationMin()).isEqualTo(240);
        // Gerçek boy kaybolmuyor: PDF'te «Toplam» sütununda bu değer yazılı.
        assertThat(longest.get(1).durationMin()).isGreaterThan(20_000);
    }

    @Test
    @DisplayName("Sertifika bitişleri MEVCUT erişilebilirlik satırlarından türetilir — ek sorgu YOK")
    void certExpiriesAreDerivedFromAvailabilityRows() {
        List<AvailabilityRow> rows = List.of(
                new AvailabilityRow("yakin.com", 99.9, 0, 0, 0, 100L, 120L, 12),
                new AvailabilityRow("uzak.com", 100.0, 0, 0, 0, 100L, 120L, 200),
                new AvailabilityRow("orta.com", 99.9, 0, 0, 0, 100L, 120L, 45),
                new AvailabilityRow("veriyok.com", null, 0, 0, 0, null, null, null));

        var expiries = service.collect(TEAM, W, rows).certExpiries();

        // ≤60 gün süzgeci + kalan güne göre artan sıralama korunur.
        assertThat(expiries).extracting(WeeklyOutageReportService.CertExpiry::domain)
                .containsExactly("yakin.com", "orta.com");
        assertThat(expiries.get(0).daysRemaining()).isEqualTo(12);
        // Sertifika günü ZATEN AvailabilityRow'da geliyor; eskiden domain başına yeniden
        // sorgulanıyordu. Bağımlılık yapıcıdan kalktığı için tekrar sorgu DERLEME düzeyinde
        // imkânsız — bu test de veriyle aynı sonucu ürettiğini kilitliyor.
    }

    @Test
    @DisplayName("Bakım pencerelerinin hedefleri pencere BAŞINA BİR KEZ ayrıştırılır")
    void maintenanceTargetsAreParsedOncePerWindow() {
        MaintenanceWindow win = new MaintenanceWindow();
        win.setId(1L);
        when(maintenanceRepo.findAll()).thenReturn(List.of(win));
        when(maintenanceService.targetsOf(win)).thenReturn(List.of("a.com"));
        when(maintenanceService.isActiveAt(eq(win), any())).thenReturn(false);
        // Çok alarmlı senaryo: eskiden targetsOf alarm × pencere döngüsünün İÇİNDEN çağrılıyordu
        // ve her çağrıda hedef JSON'u Jackson ile baştan ayrıştırılıyordu.
        List<AlertEvent> many = new java.util.ArrayList<>();
        for (int i = 0; i < 25; i++) many.add(alarm(i + 1, "h" + i + ".com", "HTTP_DOWN", "2026-06-16T09:00:00"));
        stubAlarms(many, List.of(), List.of());

        collect();

        org.mockito.Mockito.verify(maintenanceService, org.mockito.Mockito.times(1)).targetsOf(win);
    }

    // ── Kapsam (IDOR) ────────────────────────────────────────────────────────

    @Test
    @DisplayName("Alarm sorguları TAKIM KAPSAMLI koşar — rapor başka takımın alarmına açılamaz")
    void alarmQueriesAreTeamScoped() {
        collect();

        // Üç kapsam sorgusunun ÜÇÜ de scoped=true ve scope=[takım] ile çağrılmalı. Biri bile
        // scoped=false gitse PDF tüm kurumun alarmlarını takıma göndermiş olurdu.
        org.mockito.Mockito.verify(alertEventRepo, org.mockito.Mockito.times(3)).findFiltered(
                any(), any(), any(), any(), any(), any(), any(),
                eq(true), eq(List.of(5L)), any());
        org.mockito.Mockito.verify(alertEventRepo, org.mockito.Mockito.never()).findFiltered(
                any(), any(), any(), any(), any(), any(), any(),
                eq(false), any(), any());
    }

    // ── Dosya adı ────────────────────────────────────────────────────────────

    @Test
    @DisplayName("Dosya adı: Türkçe/boşluklu takım adı dosya adına güvenli hâle gelir")
    void fileNameIsFilesystemSafe() {
        assertThat(WeeklyOutageReportService.fileName("Dijital SY", W))
                .isEqualTo("haftalik-kesinti-raporu_dijital-sy_2026-W25.pdf");
        assertThat(WeeklyOutageReportService.fileName("Ağ & Güvenlik / Ops", W))
                .isEqualTo("haftalik-kesinti-raporu_ağ-güvenlik-ops_2026-W25.pdf");
        assertThat(WeeklyOutageReportService.fileName(null, W)).contains("takim");
    }

    // ── Yardımcı ─────────────────────────────────────────────────────────────

    private static Map<String, OutageRow> index(WeeklyOutageData d) {
        return d.groups().stream().flatMap(g -> g.rows().stream())
                .collect(java.util.stream.Collectors.toMap(OutageRow::target, r -> r, (a, b) -> a));
    }
}
