package com.sitemonitor.controller;

import com.sitemonitor.model.SmtpSettings;
import com.sitemonitor.service.AuditService;
import com.sitemonitor.service.HttpMetricsService;
import com.sitemonitor.service.RememberMeService;
import com.sitemonitor.service.SmtpMailService;
import com.sitemonitor.service.SmtpSettingsService;
import com.sitemonitor.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SmtpAdminController.class)
class SmtpAdminControllerTest {

    @Autowired MockMvc mvc;

    @MockitoBean SmtpSettingsService settingsService;
    @MockitoBean SmtpMailService mailService;
    @MockitoBean AuditService auditService;
    @MockitoBean com.sitemonitor.service.PermissionService permissionService;

    // Beans pulled in by WebConfig / AuthInterceptor / HttpMetricsInterceptor.
    @MockitoBean RememberMeService rememberMeService;
    @MockitoBean UserService userService;
    @MockitoBean AuthController authController;
    @MockitoBean HttpMetricsService httpMetricsService;

    @BeforeEach
    void setUp() {
        when(settingsService.getOrDefaults()).thenReturn(new SmtpSettings());
        when(settingsService.isConfigured()).thenReturn(false);
        when(settingsService.toClientMap(any()))
                .thenReturn(Map.of("enabled", true, "host", "smtp.gmail.com", "password_set", true));
        // Bootstrap admin ("admin") require'ı atlar (erken dönüş); non-bootstrap için require çağrılır →
        // matris izni reddini simüle etmek için her zaman fırlat (→ 403). Bootstrap happy-path etkilenmez.
        org.mockito.Mockito.doThrow(new SecurityException("no perm")).when(permissionService)
                .require(org.mockito.ArgumentMatchers.any(jakarta.servlet.http.HttpSession.class),
                        org.mockito.ArgumentMatchers.anyString(), org.mockito.ArgumentMatchers.anyString());
    }

    @Test
    @DisplayName("GET /settings unauthenticated → 401")
    void getSettings_unauthenticated_401() throws Exception {
        mvc.perform(get("/api/admin/smtp/settings"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @DisplayName("GET /settings as non-bootstrap ADMIN → 403")
    void getSettings_nonBootstrapAdmin_403() throws Exception {
        mvc.perform(get("/api/admin/smtp/settings").session(adminRoleButNotBootstrap()))
                .andExpect(status().isForbidden());
    }

    @Test
    @DisplayName("GET /settings as bootstrap admin → 200, no password leaked")
    void getSettings_bootstrapAdmin_200() throws Exception {
        mvc.perform(get("/api/admin/smtp/settings").session(bootstrapAdmin()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.password_set").value(true))
                .andExpect(jsonPath("$.data.password").doesNotExist());
    }

    @Test
    @DisplayName("PUT /settings as bootstrap admin → 200")
    void saveSettings_bootstrapAdmin_200() throws Exception {
        when(settingsService.save(any(), eq("admin"))).thenReturn(new SmtpSettings());
        mvc.perform(put("/api/admin/smtp/settings")
                        .session(bootstrapAdmin())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"enabled\":true,\"host\":\"smtp.gmail.com\",\"port\":587}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true));
    }

    @Test
    @DisplayName("POST /test returns the connection result")
    void testConnection_returnsResult() throws Exception {
        when(mailService.testConnection()).thenReturn(Map.of("success", true, "message", "ok"));
        mvc.perform(post("/api/admin/smtp/test").session(bootstrapAdmin()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.message").value("ok"));
    }

    @Test
    @DisplayName("POST /test-email surfaces failures inline (200, success=false)")
    void sendTest_failureInline() throws Exception {
        when(mailService.sendTest("a@b.com"))
                .thenReturn(Map.of("success", false, "error", "Connection refused"));
        mvc.perform(post("/api/admin/smtp/test-email")
                        .session(bootstrapAdmin())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"recipient\":\"a@b.com\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(false))
                .andExpect(jsonPath("$.error").value("Connection refused"));
    }

    @Test
    @DisplayName("POST /test-email as non-bootstrap ADMIN → 403")
    void sendTest_nonBootstrapAdmin_403() throws Exception {
        mvc.perform(post("/api/admin/smtp/test-email")
                        .session(adminRoleButNotBootstrap())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"recipient\":\"a@b.com\"}"))
                .andExpect(status().isForbidden());
    }

    private MockHttpSession bootstrapAdmin() {
        MockHttpSession s = new MockHttpSession();
        s.setAttribute("authenticated", Boolean.TRUE);
        s.setAttribute("username", "admin");
        s.setAttribute("bootstrapAdmin", Boolean.TRUE);   // settings gate bayrağı (literal username yerine)
        s.setAttribute("systemRole", "ADMIN");
        return s;
    }

    private MockHttpSession adminRoleButNotBootstrap() {
        MockHttpSession s = new MockHttpSession();
        s.setAttribute("authenticated", Boolean.TRUE);
        s.setAttribute("username", "erdi");
        s.setAttribute("systemRole", "ADMIN");
        return s;
    }
}
